exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify({
      message: "Placeholder — homebase-dev",
      path: event.rawPath || event.path,
      timestamp: new Date().toISOString(),
    }),
  };
};
